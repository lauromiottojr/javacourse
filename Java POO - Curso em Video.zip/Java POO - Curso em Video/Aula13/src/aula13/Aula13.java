package aula13;

public class Aula13 {

    public static void main(String[] args) {

        Cachorro c = new Cachorro();
        c.reagir(19, 25);
    }

}
