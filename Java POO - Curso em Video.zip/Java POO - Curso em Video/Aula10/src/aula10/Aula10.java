package aula10;

public class Aula10 {

    public static void main(String[] args) {
        Aluno p1 = new Aluno("Rogerinho", 10, "M");
        Professor p2 = new Professor("Ricardo", 40, "M");
        Funcionario p3 = new Funcionario("Tania", 25, "F");

        p2.setSalario(1000);
        p2.receberAumento(303);
        
        p3.setTrabalhando(true);
        p3.mudarTrabalho();

        p1.fazerAniv();
        p1.cancelarMatricula();
        System.out.println(p1.getMatricula());
        
        System.out.println(p1.toString());
        
    }

}
