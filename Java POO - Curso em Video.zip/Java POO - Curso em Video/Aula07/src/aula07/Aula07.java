package aula07;

import java.util.Random;

public class Aula07 {

    public static void main(String[] args) {
        Lutador l[] = new Lutador[6];
        l[0] = new Lutador("Pretty Boy", "França",
                31, 1.75f, 68.9f, 11, 2, 1);

        l[1] = new Lutador("Putscript", "Brasil",
                29, 1.68f, 57.8f, 14, 2, 3);

        l[2] = new Lutador("Snapshadow", "EUA",
                35, 1.65f, 80.9f, 12, 2, 1);

        l[3] = new Lutador("Dead Code", "Austrália",
                28, 1.93f, 81.6f, 13, 0, 2);

        l[4] = new Lutador("UFOCobol", "Brasil",
                37, 1.70f, 119.3f, 5, 4, 3);

        l[5] = new Lutador("Nerdaart", "EUA",
                40, 1.81f, 105.7f, 12, 2, 4);

        /*for (int i = 0; i <= 5; i++) {
            l[i].apresentar();
        }*/
        Luta uec01 = new Luta();
        Random num1 = new Random();
        Random num2 = new Random();
        int lut1 = num1.nextInt(5);
        int lut2 = num2.nextInt(5);
        uec01.marcarLuta(l[lut1], l[lut2]);
        uec01.lutar();
    }

}
