package aula09;

public class Aula09 {

    public static void main(String[] args) {
        Pessoa p1 = new Pessoa();
        p1.setNome("Lauro");
        p1.setIdade(24);
        p1.setSexo("M");

        p1.fazerAniv();

        Livro l1 = new Livro("Homem de ferro", "Laurinho", 10, p1);
        l1.detalhes();
        l1.folhear();
    }

}
