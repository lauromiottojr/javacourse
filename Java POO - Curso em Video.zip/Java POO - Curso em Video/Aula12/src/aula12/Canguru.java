package aula12;

public class Canguru extends Mamifero {

    public void usarBolsa() {

    }

    @Override
    public void locomover() {
        System.out.println("Salta!");
    }
}
