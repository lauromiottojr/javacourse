package aula12;

public class Cachorro extends Mamifero {

    public void enterrarOsso() {

    }

    public void abanarRabo() {

    }
}
