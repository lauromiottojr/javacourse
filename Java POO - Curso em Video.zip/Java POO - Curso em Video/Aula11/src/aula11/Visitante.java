package aula11;

public class Visitante extends Pessoa {

}
