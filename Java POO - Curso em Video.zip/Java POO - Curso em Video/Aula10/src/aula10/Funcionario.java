package aula10;

public class Funcionario extends Pessoa {

    private String setor;
    private boolean trabalhando;

    // métodos especiais
    public Funcionario(String nome, int idade, String sexo) {
        super(nome, idade, sexo);
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public boolean getTrabalhando() {
        return trabalhando;
    }

    public void setTrabalhando(boolean trabalhando) {
        this.trabalhando = trabalhando;
    }

    //métodos
    public void mudarTrabalho() {
        if (this.getTrabalhando()) {
            this.setTrabalhando(false);
            System.out.println(this.getNome() + " agora vai descansar!");
        } else {
            this.setTrabalhando(true);
            System.out.println(this.getNome() + " agora vai começar a trabalhar!");
        }
    }
}
