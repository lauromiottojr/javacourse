package aula10;

public class Professor extends Pessoa {

    private String especialidade;
    private float salario;

    // métodos especiais
    public Professor(String nome, int idade, String sexo) {
        super(nome, idade, sexo);
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    //métodos
    public void receberAumento(float a) {
        this.setSalario(this.getSalario() + a);
        System.out.println("O professor " + this.getNome() + " recebeu um aumento e agora ganha R$" + 
                this.getSalario());
    }
}
