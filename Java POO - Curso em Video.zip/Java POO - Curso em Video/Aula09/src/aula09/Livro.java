package aula09;

import java.util.Random;

public class Livro implements Publicacao {

    private String titulo;
    private String autor;
    private int totPag;
    private int pagAtual;
    private boolean aberto;
    private Pessoa leitor;

    //métodos especiais
    public Livro(String titulo, String autor, int totPag, Pessoa leitor) {
        this.titulo = titulo;
        this.autor = autor;
        this.totPag = totPag;
        this.pagAtual = 0;
        this.aberto = false;
        this.leitor = leitor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getTotPag() {
        return totPag;
    }

    public void setTotPag(int totPag) {
        this.totPag = totPag;
    }

    public int getPagAtual() {
        return pagAtual;
    }

    public void setPagAtual(int pagAtual) {
        this.pagAtual = pagAtual;
    }

    public boolean getAberto() {
        return aberto;
    }

    public void setAberto(boolean aberto) {
        this.aberto = aberto;
    }

    public Pessoa getLeitor() {
        return leitor;
    }

    public void setLeitor(Pessoa leitor) {
        this.leitor = leitor;
    }

    // métodos
    public void detalhes() {
        System.out.println("Livro: " + this.getTitulo());
        System.out.println("Autor: " + this.getAutor());
        System.out.println("Total de páginas: " + this.getTotPag());
        if (this.getAberto()) {
            System.out.println("O livro está aberto!");
        } else {
            System.out.println("O livro está fechado!");
        }
        System.out.println("Seu leitor atual é o: " + this.getLeitor().getNome());
    }

    @Override
    public void abrir() {
        if (this.getAberto()) {
            System.out.println("O livro já está aberto!");
        } else {
            this.setAberto(true);
            System.out.println("Livro aberto com sucesso!");
        }
    }

    @Override
    public void fechar() {
        if (this.getAberto()) {
            this.setAberto(false);
            System.out.println("Livro fechado com sucesso!");
        } else {
            System.out.println("Livro já está fechado!");
        }
    }

    @Override
    public void folhear() {
        Random r = new Random();
        int pagRandom = r.nextInt(this.getTotPag());
        System.out.println("Folheado, a página atual é: " + pagRandom);
    }

    @Override
    public void avancarPag() {
        if (this.getPagAtual() == this.getTotPag()) {
            System.out.println("Livro chegou ao fim!");
        } else if (this.getPagAtual() < this.getTotPag()) {
            this.setPagAtual(this.getPagAtual() + 1);
            System.out.println("Página avançada, a atual é a " + this.getPagAtual());
        }
    }

    @Override
    public void voltarPag() {
        if (this.getPagAtual() == 1) {
            System.out.println("O livro está na primeira página, impossível voltar!");
        } else if (this.getPagAtual() > 1 && this.getPagAtual() <= this.getTotPag()) {
            this.setPagAtual(this.getPagAtual() - 1);
            System.out.println("Página retornada, a atual é a " + this.getPagAtual());
        }
    }
}
