package aula07;

public interface Controlador {

    public abstract void apresentar();

    public abstract void status();

    public abstract void ganharLuta();

    public abstract void perderLuta();

    public abstract void empatarLuta();

    public abstract void marcarLuta(Lutador l1, Lutador l2);

    public abstract void lutar();

}
