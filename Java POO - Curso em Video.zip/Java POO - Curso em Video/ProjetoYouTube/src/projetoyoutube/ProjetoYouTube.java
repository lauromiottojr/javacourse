package projetoyoutube;

public class ProjetoYouTube {
    
    public static void main(String[] args) {
        Video v[] = new Video[3];
        v[0] = new Video("Aula 1 POO");
        v[1] = new Video("Aula 12 Java");
        v[2] = new Video("Aula 10 PHP");
        
        Gafanhoto g = new Gafanhoto("Lauro", 24, "M", "Lauro balada");
        
        Visualizacao vis = new Visualizacao(g, v[0]);
        vis.avaliar();
        Visualizacao vis1 = new Visualizacao(g, v[0]);
        vis1.avaliar(100f);
        System.out.println(vis.toString());
        System.out.println(g.toString());
        
    }
    
}
