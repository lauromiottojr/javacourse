package aula12;

public class Cobra extends Reptil {

}
