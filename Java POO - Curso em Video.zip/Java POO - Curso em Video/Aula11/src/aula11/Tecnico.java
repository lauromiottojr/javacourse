package aula11;

public class Tecnico {

    private int registroProfissional;

    public void publicar() {

    }

    // métodos especiais
    public int getRegistroProfissional() {
        return registroProfissional;
    }

    public void setRegistroProfissional(int registroProfissional) {
        this.registroProfissional = registroProfissional;
    }

}
