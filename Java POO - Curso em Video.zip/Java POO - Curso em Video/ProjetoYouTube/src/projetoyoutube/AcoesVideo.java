package projetoyoutube;

public interface AcoesVideo {

    public abstract void play();

    public abstract void pause();

    public abstract void like();
}
