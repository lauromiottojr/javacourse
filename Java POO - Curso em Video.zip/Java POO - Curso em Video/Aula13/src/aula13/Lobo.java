package aula13;

public class Lobo extends Mamifero {

    @Override
    public void emitirSom() {
        System.out.println("Auuuuuuuuuuu!");
    }
}
